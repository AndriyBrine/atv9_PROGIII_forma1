import atv9_20251Mod
def main():
	listamulheres = list()
	listahomens = list()

	nomearquivoM = str("mulheresIBGECSV.csv")
	nomearquivoH = str("homensIBGECSV.csv")
	listamulheres = atv9_20251Mod.f_somavaloreslista(nomearquivoM)
	listahomens = atv9_20251Mod.f_somavaloreslista(nomearquivoH)

	texto1 = str("MULHERES")
	texto2 = str("HOMENS")
	nomearquivoSaida = str("saida.txt")
	atv9_20251Mod.f_printsaida(listamulheres, listahomens, texto1, texto2, nomearquivoSaida)

if __name__ == '__main__':
	main()