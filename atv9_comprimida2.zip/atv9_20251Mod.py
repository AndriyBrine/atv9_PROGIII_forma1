def f_somavaloreslista(nomearquivo:str)->list():
	total = int()
	lst_total = list()
	with open(nomearquivo, 'r', encoding='utf-8') as arquivo:
		for linha in arquivo:
			lista = linha.split(",")
			for i in range(len(lista) - 5):
				pessoasidade = int(lista[i + 5])
				total = total + pessoasidade
			lst_total.append(total)
	return lst_total

def f_printsaida(lista1: list, lista2: list(), texto:str, texto2: str, nomearquivo:str)->None:
	with open(nomearquivo, 'w', encoding='utf-8') as arquivo:
		arquivo.write(texto + "\n")
		for i in range(91):
			arquivo.write("IDADE=" + str(i) + " QTD=" + str(lista1[i]) +"\n")

		arquivo.write(texto2 + "\n")
		for i in range(91):
			arquivo.write("IDADE=" + str(i) + " QTD=" + str(lista2[i]) +"\n")
	
	print(texto)
	for i in range(91):
		print("IDADE=%d QTD=%d" % (i, lista1[i]))
	print(texto2)
	for i in range(91):
		print("IDADE=%d QTD=%d" % (i, lista2[i]))
	

